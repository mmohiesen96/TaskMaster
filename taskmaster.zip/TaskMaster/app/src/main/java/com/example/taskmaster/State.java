package com.example.taskmaster;

public enum State {
    NEW, ASSIGNED,IN_PROGRESS, COMPLETE
}
